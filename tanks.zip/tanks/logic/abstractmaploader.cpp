

#include "abstractmaploader.h"

namespace Tanks {

AbstractMapLoader::AbstractMapLoader() { }

AbstractMapLoader::~AbstractMapLoader() { }

} // namespace Tanks
