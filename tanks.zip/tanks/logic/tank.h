

#ifndef TANKS_TANK_H
#define TANKS_TANK_H

#include "bullet.h"
#include "dynamicblock.h"
#include "shield.h"
#include "bonus.h"

namespace Tanks {

class Tank : public DynamicBlock {
    Q_OBJECT
public:
    enum FriendlyVariant {
        SmallTank,
        SpeedFireTank,
        BurstFireTank,
        ArmorPiercingTank,
    };

    enum EnemyVariant {
        RegularTank,
        SpeedyTank,
        FastBulletTank,
        ArmoredTank,

        LastEnemyVariant
    };

    Tank(Affinity affinity, quint8 variant = 0);

    inline Affinity affinity() const { return _affinity; }
    inline quint8   variant() const { return _variant; }
    inline int      points() const {return _points;}
    void            setTankDefaults();

    inline bool canShoot() const { return _shootTicks == 0; }

    bool isArmorPiercing() const { return (_affinity == Friendly) && (_variant == ArmorPiercingTank); }

    void fire();
    void resetShootClock();

    OutBoardAction outBoardAction() const;

    void clockTick();

    void catchBullet();
    void selfDestroy();
    void createShield();

    void createBonus();
    void catchBonus(int);

    QSharedPointer<Bullet> takeBullet()
    {
        QSharedPointer<Bullet> ret;
        _bullet.swap(ret);
        return ret;
    }

    QSharedPointer<Bonus> takeBonus()
    {
        QSharedPointer<Bonus> ret;
        _bonus.swap(ret);
        return ret;
    }

    QSharedPointer<Bullet> bullet() const { return _bullet; }
    QSharedPointer<Shield> shield() const { return _shield; }
    QSharedPointer<Bonus> bonus() const { return _bonus; }

signals:
    void tankDestroyed();
    void armourChanged();
    void fired();
    void shielded();
    void bonused(int);

    void destroyAll();
    void lifeAdded();
    void freezed();
    void levelUp();
    void concreteBase();

private:
    Affinity               _affinity;
    quint8                 _variant;
    quint8                 _armorLevel;
    quint8                 _bulletCount;
    quint8                 _bonusIndex;
    int                    _shootTicks;
    int                    _points;
    QSharedPointer<Bullet> _bullet;
    QSharedPointer<Shield> _shield;
    QSharedPointer<Bonus> _bonus;

};

} // namespace Tanks

#endif // TANKS_TANK_H
