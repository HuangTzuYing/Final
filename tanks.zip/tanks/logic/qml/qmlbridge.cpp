

#include <QDebug>
#include <QImage>
#include <QPainter>
#include <QStandardPaths>

#include "abstractmaploader.h"
#include "board.h"
#include "flag.h"
#include "game.h"
#include "qmlbridge.h"
#include "qmlmapimageprovider.h"
#include "tank.h"

namespace Tanks {

static int minBlockSize = 8; // 4px. minimal breakable part or minimal move

QMLBridge::QMLBridge(QObject *parent) : QObject(parent), _qmlId(0)
{
    QMLMapImageProvider::registerBridge(this);

    _game = new Game(this);
    connect(_game, &Game::mapLoaded, this, &QMLBridge::mapLoaded);
    connect(_game, &Game::baseChanged, this, &QMLBridge::baseChanged);    
    connect(_game, &Game::newTank, this, &QMLBridge::newTankAvailable);

    connect(_game, &Game::blockRemoved, this, &QMLBridge::removeBlock);
    connect(_game, &Game::flagLost, this, &QMLBridge::flagChanged);
    connect(_game, &Game::statsChanged, this, &QMLBridge::statsChanged);
    // connect(_game, &Game::playerRestarted, this, &QMLBridge::playerRestarted)

    connect(this, SIGNAL(qmlTankAction(int, int)), SLOT(humanTankAction(int, int)));
    connect(this, SIGNAL(qmlTankActionStop(int, int)), SLOT(humanTankActionStop(int, int)));
    _game->start();
}

QImage QMLBridge::lowerMapImage() const { return _lowerMapImage; }

QImage QMLBridge::bushImage() const { return _bushImage; }

QSize QMLBridge::boardImageSize() const { return _game->board()->size() * minBlockSize; }

QRect QMLBridge::flagGeometry() const
{
    QRect g = _game->flag()->geometry();
    return QRect(g.topLeft() * minBlockSize, g.size() * minBlockSize);
}

QString QMLBridge::flagFile() const { return _game->flag()->isBroken() ? "img/loss" : "img/base"; }

QString QMLBridge::lifesStat() const
{
    QString lifes = QString("<b>AI: %1</b><br>").arg(_game->aiLifes());
    for (int i = 0; i < _game->playersCount(); i++) {
        lifes += QString("<b>P%1: %2</b><br>").arg(QString::number(i + 1), QString::number(_game->playerLifes(i)));
    }
    return lifes;
}

QString QMLBridge::playStat() const
{
    QString scores = QString("<b>Player Score:</b><br>");
    for (int i = 0; i < _game->playersCount(); i++) {
        scores += QString("<b>P%1: %2</b><br>").arg(QString::number(i + 1), QString::number(_game->playerScore(i)));
    }
    return scores;
}


void QMLBridge::setBridgeId(const QString &id) { _bridgeId = id; }

void QMLBridge::mapLoaded()
{
    qDebug() << "Map loaded!";

    //_activeBlocks.clear();

    static const char *textures[LastMapObjectType] = {
        0, ":/img/concrete", ":/img/brick", ":/img/bush", ":/img/ice", ":/img/water",
    };
    static QVector<QImage> probes; // keeps full scaled textures.
    // into this size we should draw our texture to fully fit.
    // In short, Baord spliited blocks from MapLoader into smaller pieces and
    // now we need to bring back original size to render textures properly.
    QSize scaledTextureSize(minBlockSize * _game->board()->blockDivider(),
                            minBlockSize * _game->board()->blockDivider());
    if (probes.isEmpty()) {
        probes.resize(LastMapObjectType);
        for (int i = 0; i < LastMapObjectType; i++) {
            probes[i] = QImage(scaledTextureSize, QImage::Format_ARGB32);
            QPainter p(&probes[i]);
            if (textures[i]) {
                p.fillRect(probes[i].rect(), QBrush(QImage(textures[i]).scaled(scaledTextureSize)));
            } else {
                probes[i].fill(0);
            }
        }
    }

    _lowerMapImage = QImage(_game->board()->size() * minBlockSize, QImage::Format_ARGB32);
    _lowerMapImage.fill(0);
    QPainter lowerPainter(&_lowerMapImage);

    _bushImage = QImage(_game->board()->size() * minBlockSize, QImage::Format_ARGB32);
    _bushImage.fill(0);
    QPainter bushPainter(&_bushImage);

    Board::Iterator it = _game->board()->iterate();
    while (it.isValid()) {
        QPainter *painter = *it == Bush ? &bushPainter : &lowerPainter;
        QImage   &probe   = probes[*it];
        QPoint    pos     = it.pos() * minBlockSize;
        int       probeX  = pos.x() % (_game->board()->blockDivider() * minBlockSize);
        int       probeY  = pos.y() % (_game->board()->blockDivider() * minBlockSize);
        painter->drawImage(pos, probe, QRect(probeX, probeY, minBlockSize, minBlockSize));
        ++it;
    }

    // that's the most easy way. QQuickImageProvider is just a holy crap (I'm sorry)
    // and QSG* is probably not expected by interviewers and it's anyway even
    // more complicated even if idealogically more correct.
    // lowerLayer.save(_lowerFilename);
    // bushLayer.save(_bushFilename);

    emit mapRendered();
}

void QMLBridge::baseChanged()
{
    qDebug() << "Map loaded!";

    //_activeBlocks.clear();

    static const char *textures[LastMapObjectType] = {
        0, ":/img/concrete", ":/img/brick", ":/img/bush", ":/img/ice", ":/img/water",
    };
    static QVector<QImage> probes; // keeps full scaled textures.
    // into this size we should draw our texture to fully fit.
    // In short, Baord spliited blocks from MapLoader into smaller pieces and
    // now we need to bring back original size to render textures properly.
    QSize scaledTextureSize(minBlockSize * _game->board()->blockDivider(),
                            minBlockSize * _game->board()->blockDivider());
    if (probes.isEmpty()) {
        probes.resize(LastMapObjectType);
        for (int i = 0; i < LastMapObjectType; i++) {
            probes[i] = QImage(scaledTextureSize, QImage::Format_ARGB32);
            QPainter p(&probes[i]);
            if (textures[i]) {
                p.fillRect(probes[i].rect(), QBrush(QImage(textures[i]).scaled(scaledTextureSize)));
            } else {
                probes[i].fill(0);
            }
        }
    }

    _lowerMapImage = QImage(_game->board()->size() * minBlockSize, QImage::Format_ARGB32);
    _lowerMapImage.fill(0);
    QPainter lowerPainter(&_lowerMapImage);

    _bushImage = QImage(_game->board()->size() * minBlockSize, QImage::Format_ARGB32);
    _bushImage.fill(0);
    QPainter bushPainter(&_bushImage);

    Board::Iterator it = _game->board()->iterate();
    while (it.isValid()) {
        QPainter *painter = *it == Bush ? &bushPainter : &lowerPainter;
        QImage   &probe   = probes[*it];
        QPoint    pos     = it.pos() * minBlockSize;
        int       probeX  = pos.x() % (_game->board()->blockDivider() * minBlockSize);
        int       probeY  = pos.y() % (_game->board()->blockDivider() * minBlockSize);
        painter->drawImage(pos, probe, QRect(probeX, probeY, minBlockSize, minBlockSize));
        ++it;
    }

    // that's the most easy way. QQuickImageProvider is just a holy crap (I'm sorry)
    // and QSG* is probably not expected by interviewers and it's anyway even
    // more complicated even if idealogically more correct.
    // lowerLayer.save(_lowerFilename);
    // bushLayer.save(_bushFilename);

    emit baseRendered();
}

void QMLBridge::newTankAvailable(QObject *obj)
{
    Tank *tank = qobject_cast<Tank *>(obj);

    connect(tank, &Tank::fired, this, &QMLBridge::newBulletAvailable);
    connect(tank, &Tank::moved, this, &QMLBridge::moveTank);
    connect(tank, &Tank::tankDestroyed, this, &QMLBridge::destroyTank);
    connect(tank, &Tank::shielded, this, &QMLBridge::newShieldAvailable);
    connect(tank, &Tank::bonused, this, &QMLBridge::newBonusAvailable);

    QString id = QString("tank") + QString::number(_qmlId++);
    //_activeBlocks.insert(id, tank.dynamicCast<Block>());
    tank->setProperty("qmlid", id);
    emit newTank(tank2variant(tank));
}

void QMLBridge::newBulletAvailable()
{
    Bullet *bullet = qobject_cast<Tank *>(sender())->bullet().data();

    connect(bullet, &DynamicBlock::moved, this, &QMLBridge::moveBullet);

    QString id = QString("bullet") + QString::number(_qmlId++);
    //_activeBlocks.insert(id, tank.dynamicCast<Block>());
    bullet->setProperty("qmlid", id);

    QVariantMap vb;
    vb["id"] = id;
    // vb["affinity"] = bullet->affinity();
    vb["direction"] = (int)bullet->direction();
    QRect geom      = bullet->geometry();
    vb["geometry"]  = QRect(geom.topLeft() * minBlockSize, geom.size() * minBlockSize);

    connect(bullet, &Bullet::detonated, this, &QMLBridge::detonateBullet);
    emit newBullet(vb);
}

void QMLBridge::newShieldAvailable()
{
    qDebug() << "New shield!";

    Shield *shield = qobject_cast<Tank *>(sender())->shield().data();

    // connect(shield, &DynamicBlock::moved, this, &QMLBridge::moveBullet);

    QString id = QString("shield") + QString::number(_qmlId++);
    //_activeBlocks.insert(id, tank.dynamicCast<Block>());
    shield->setProperty("qmlid", id);

    QVariantMap vb;
    vb["id"] = id;
    // vb["affinity"] = bullet->affinity();
    // vb["direction"] = (int)bullet->direction();
    QRect geom      = shield->geometry();
    vb["geometry"]  = QRect(geom.topLeft() * minBlockSize, geom.size() * minBlockSize);

    qDebug() << "new shield, id:" << id;    
    emit newShield(vb);
}


void QMLBridge::moveTank()
{
    auto tank = qobject_cast<Tank *>(sender());
    emit tankUpdated(tank2variant(tank));

    Shield *shield = qobject_cast<Tank *>(sender())->shield().data();
    if(shield != nullptr && shield->isVisable()) {
        QPoint pos = tank->geometry().topLeft() * minBlockSize;
        QString shieldId = shield->property("qmlid").toString();
        emit shieldMoved(shieldId, pos);
    }
}

void QMLBridge::destroyTank() { emit tankDestroyed(sender()->property("qmlid").toString()); }

void QMLBridge::moveBullet()
{
    auto bullet = qobject_cast<Bullet *>(sender());
    // qDebug() << "New position: " << bullet->geometry().topLeft() * minBlockSize;    
    emit bulletMoved(bullet->property("qmlid").toString(), bullet->geometry().topLeft() * minBlockSize);
}

void QMLBridge::detonateBullet()
{
    auto bullet = qobject_cast<Bullet *>(sender());
    emit bulletDetonated(bullet->property("qmlid").toString(), (int)bullet->explosionType());
}

QVariant QMLBridge::tank2variant(Tank *tank)
{
    QVariantMap vtank;
    vtank["id"]        = tank->property("qmlid").toString();
    vtank["affinity"]  = (int)tank->affinity();
    vtank["variant"]   = tank->variant();
    vtank["direction"] = (int)tank->direction();
    QRect tankGeom     = tank->geometry();
    vtank["geometry"]  = QRect(tankGeom.topLeft() * minBlockSize, tankGeom.size() * minBlockSize);
    return vtank;
}

QVariant QMLBridge::shield2variant(Shield *shield)
{
    QVariantMap vb;
    vb["id"]        = shield->property("qmlid").toString();
    QRect geom      = shield->geometry();
    vb["geometry"]  = QRect(geom.topLeft() * minBlockSize, geom.size() * minBlockSize);
    return vb;
}


void QMLBridge::restart(int playersCount) { _game->start(playersCount); }

void QMLBridge::removeBlock(const QRect &r)
{
    emit blockRemoved(QRect(r.topLeft() * minBlockSize, r.size() * minBlockSize));
}

void QMLBridge::humanTankAction(int player, int key)
{
    // qDebug() << "Catched start!";
    if (key < 4) {
        _game->playerMoveRequested(player, key);
    } else {
        _game->playerFireRequested(player);
    }
}

void QMLBridge::humanTankActionStop(int player, int key)
{
    // qDebug() << "Catched stop!";
    if (key < 4) {
        _game->playerStopMoveRequested(player, key);
    } else {
        _game->playerStopFireRequested(player);
    }
}

void QMLBridge::newBonusAvailable(int type)
{
    qDebug() << "New bonus!" << type;

    Bonus *bonus = qobject_cast<Tank *>(sender())->bonus().data();

    // connect(shield, &DynamicBlock::moved, this, &QMLBridge::moveBullet);

    QString id = QString("bonus") + QString::number(_qmlId++);
    //_activeBlocks.insert(id, tank.dynamicCast<Block>());
    bonus->setProperty("qmlid", id);

    QVariantMap vb;
    vb["id"] = id;
    // vb["affinity"] = bullet->affinity();
    // vb["direction"] = (int)bullet->direction();
    vb["type"] = (int)bonus->type();
    QRect geom      = bonus->geometry();
    vb["geometry"]  = QRect(geom.topLeft() * minBlockSize, geom.size() * minBlockSize);

    qDebug() << "new bonus, id:" << id << ",pos:" << geom;    
    connect(bonus, &Bonus::changed, this, &QMLBridge::detonateBonus);
    emit newBonus(vb);
}

void QMLBridge::detonateBonus()
{
    auto bonus = qobject_cast<Bonus *>(sender());
    emit bonusDetonated(bonus->property("qmlid").toString(), bonus->type());
}



} // namespace Tanks
