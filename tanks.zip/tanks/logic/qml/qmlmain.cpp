

#include <QQmlApplicationEngine>
#include <QtQml>

#include "qmlbridge.h"
#include "qmlmain.h"
#include "qmlmapimageprovider.h"
#include "qmltankimageprovider.h"

namespace Tanks {

QMLMain::QMLMain()
{

    qmlRegisterType<Tanks::QMLBridge>("com.rsoft.tanks", 1, 0, "Tanks");
    _engine = new QQmlApplicationEngine();

    _engine->addImageProvider(QLatin1String("tankprovider"), new Tanks::QMLTankImageProvider());
    _engine->addImageProvider(QLatin1String("bulletprovider"), new Tanks::QMLBulletImageProvider());
    // _engine->addImageProvider(QLatin1String("shieldprovider"), new Tanks::QMLShieldsImageProvider());
    _engine->addImageProvider(QLatin1String("mapprovider"), new Tanks::QMLMapImageProvider());
    _engine->addImageProvider(QLatin1String("bonusprovider"), new Tanks::QMLBonusImageProvider());

    _engine->load(QUrl(QStringLiteral("qrc:/main.qml")));
}

QMLMain::~QMLMain() { delete _engine; }

} // namespace Tanks
