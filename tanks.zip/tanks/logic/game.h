

#ifndef TANKS_GAME_H
#define TANKS_GAME_H

#include <QObject>
#include <QRect>
#include <QSharedPointer>

namespace Tanks {

class AbstractPlayer;
class Board;
class Flag;

class GamePrivate;
class Game : public QObject {
    Q_OBJECT
public:
    explicit Game(QObject *parent = 0);
    ~Game();
    Board                *board() const;
    QSharedPointer<Flag> &flag() const;

    void setPlayersCount(int n);
    int  playersCount();
    int  aiLifes();
    int  playerLifes(int playerId);
    int  playerScore(int playerId);

private:
    void moveBullets();
    void reset();
    void checkBonusList();

signals:
    void mapLoaded();
    void playerRestarted();
    void newTank(QObject *);
    void tankDestroyed(QObject *);
    void bulletRemoved(QObject *);
    void blockRemoved(QRect);
    void flagLost();
    void statsChanged();
    void baseChanged();

public slots:
    void playerMoveRequested(int playerNum, int direction);
    void playerFireRequested(int playerNum);
    void start(int playersCount = 1);

    void playerStopMoveRequested(int playerNum, int direction);
    void playerStopFireRequested(int playerNum);
    void destroyAllTanks();
    void freezeAllTanks();
    void concreteBase();

private slots:
    void connectPlayerSignals(Tanks::AbstractPlayer *player);
    void mapReady();
    void clockTick();

    void newTankAvailable();
    void onTankFired();
    void onBonusAvailable();

private:
    friend class GamePrivate;
    GamePrivate *_d;
};

} // namespace Tanks

#endif // TANKS_GAME_H
