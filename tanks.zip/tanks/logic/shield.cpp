#include "shield.h"

#include <QDebug>

namespace Tanks {

Shield::Shield() :
    m_visable(true),
    m_remainingTimer(new QTimer(this))
{
    _geometry.setWidth(4);
    _geometry.setHeight(4);

    qDebug() << "gen new Shield, pos:" << _geometry;

    QObject::connect(m_remainingTimer, &QTimer::timeout, this, [this](){
        setRequireToDestroy();
    });

    m_remainingTimer->start(BONUS_DURATION);
}

void Shield::resetTimer()
{
    m_remainingTimer->stop();
    m_remainingTimer->start(BONUS_DURATION);
}

DynamicBlock::OutBoardAction Shield::outBoardAction() const { return DynamicBlock::StopMove; }

void Shield::setObjectProperty(const Property &key, const QVariant &value)
{
    m_properties.insert(key, value);
}

void Shield::setRequireToDestroy(bool state)
{
    m_visable = false;
    // setObjectProperty(Property::RequireToDestroy, state);
}


} // namespace Tanks
