

#ifndef TANKS_HUMANPLAYER_H
#define TANKS_HUMANPLAYER_H

#include "abstractplayer.h"
#include "basics.h"

#include <list>

namespace Tanks {

class Game;

class HumanPlayer : public AbstractPlayer {
public:
    HumanPlayer(Game *game, int playerIndex);
    int lifesCount() const;
    int score() const;
    void addScore(int score);

    void       start();
    void       move(Direction dir);
    void       fire();
    void       stop(Direction dir);
    void       stopFire();
    inline int index() const { return _playerIndex; }

    void clockTick();
    void killAll();

protected:
    void moveToStart();

private slots:
    void onTankDestroyed();
    void onLifeAdded();

private:
    Game                *_game;
    int                  _playerIndex;
    int                  _lifes;
    int                  _score;
    bool                 _shooting;
    Direction            _oldDirection;
    std::list<Direction> _movingDir;
};

} // namespace Tanks

#endif // TANKS_HUMANPLAYER_H
