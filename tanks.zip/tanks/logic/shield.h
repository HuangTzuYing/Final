#ifndef TANKS_SHIELD_H
#define TANKS_SHIELD_H

#define SWAP_PIXMAPS_DELTA 150
#define BONUS_DURATION 10000

#include <QTimer>
#include <QGraphicsPixmapItem>
#include "dynamicblock.h"

namespace Tanks {

class Shield : public DynamicBlock, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Shield();

    enum class Property : int8_t {
        Destructible = 0,
        CanBulletMovesThroughObject,
        CanActorMovesThroughObject,
        LivesLeft,
        RequireToDestroy,
        EntityName,
        Pickable,
        Picked
    };

    void resetTimer();

    OutBoardAction outBoardAction() const;
    void setRequireToDestroy(bool state = true);
    bool isVisable() {return m_visable;}

signals:
    void shieldUpdated();

protected:
    void setObjectProperty(const Property &key, const QVariant &value);
    // const QVariant& getProperty(const Property &key) const;
private:
    // DynamicBlock *m_parent;
    QMap<Property, QVariant> m_properties;
    QTimer *m_blinkTimer;
    QTimer *m_remainingTimer;
    bool m_visable;

};

} // namespace Tanks
#endif // TANKS_SHIELD_H
