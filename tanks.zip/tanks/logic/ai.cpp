

#include "ai.h"
#include "aiplayer.h"
#include "board.h"
#include "game.h"

#include <QRandomGenerator>

namespace Tanks {

AI::AI(Game *game) : QObject(game), _game(game), _activateClock(0) { }

AI::~AI() { reset(); }

void AI::reset()
{
    _activePlayers.clear();
    _inactivePlayers.clear();
    _tanks.clear();
    _activateClock = 0;
}

void AI::start()
{
    _tanks = _game->board()->initialEnemyTanks();
    for (int i = 0; i < 8; i++) { // we want 4 tanks at once on the map
        auto robot = QSharedPointer<AIPlayer>(new AIPlayer(this));
        _inactivePlayers.push_back(robot);

        // we need this connection first to keep stats valid
        connect(robot.data(), &AIPlayer::lifeLost, this, &AI::deactivatePlayer);
        emit newPlayer(robot.data());
    }
}

QSharedPointer<AIPlayer> AI::findClash(const QSharedPointer<Block> &block)
{
    foreach (auto p, _activePlayers) {
        if (p->tank() && p->tank()->hasClash(*block)) {
            return p;
        }
    }

    foreach (auto p, _inactivePlayers) {
        if (p->tank() && p->tank()->hasClash(*block)) {
            return p;
        }
    }

    return QSharedPointer<AIPlayer>();
}

QPoint AI::initialPosition() const
{
    auto &pos = _game->board()->enemyStartPositions();
    return pos.value(QRandomGenerator::global()->bounded(pos.count()));
}

void AI::clockTick()
{
    if (_activateClock) {
        _activateClock--;
    }
    if (!_activateClock && !_inactivePlayers.empty() && _tanks.count()) {
        auto player = _inactivePlayers.front();
        _inactivePlayers.pop_front();
        _activePlayers.push_back(player);
        player->start();
        _activateClock = 100;
    }

    for (auto &p : _activePlayers) {
        p->clockTick();
    }
}

void AI::deactivatePlayer()
{
    auto it = _activePlayers.begin();
    while (it != _activePlayers.end()) {
        if ((*it).data() == sender()) {
            _inactivePlayers.push_back(*it);
            _activePlayers.erase(it);
            break;
        }
        ++it;
    }
}

void AI::killAll()
{
    foreach (auto p, _activePlayers) {
        if (p->tank() ) {
            p->tank()->catchBullet();
        }
    }
}

void AI::freezeAll()
{
    _activateClock = 100;

    auto it = _activePlayers.begin();
    while (it != _activePlayers.end()) {
        _inactivePlayers.push_back(*it);
        _activePlayers.erase(it);
        ++it;
    }
}

} // namespace Tanks
