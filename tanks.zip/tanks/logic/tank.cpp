

#include "tank.h"
#include "shield.h"
#include "bonus.h"
#include <QDebug>
#include <QRandomGenerator>

namespace Tanks {

Tank::Tank(Affinity affinity, quint8 variant) : _affinity(affinity), _variant(variant), _shootTicks(0)
{
    setTankDefaults();
    _geometry.setWidth(4); // it's in board coords. so 4 instead of expected 2
    _geometry.setHeight(4);
    _points = 0;
    switch(_variant) {
    case RegularTank:
        _points = 100;
        break;
    case SpeedyTank:
        _points = 200;
        break;
    case FastBulletTank:
        _points = 300;
        break;
    case ArmoredTank:
        _points = 400;
        break;
    }
    qDebug() << "tank points:" << _points; 
}

void Tank::setTankDefaults()
{
    _bonusIndex = 0;
    _armorLevel = 1;
    if (_affinity == Friendly) {
        _armorLevel = 1;
        if (_variant == BurstFireTank) { // burst-fire tank
            _bulletCount = 2;
        }
    } else {
        if (_variant == SpeedyTank) { // speedy
            _speed = 2;
        }
        if (_variant == ArmoredTank) { // armoured
            _armorLevel = 4;
        }
        int val = QRandomGenerator::global()->bounded(12);
        if (val > 1) { // 11
            _bonusIndex = QRandomGenerator::global()->bounded(6) + 1;
        }
    }
}

void Tank::fire()
{
    auto b = new Bullet(_affinity, isArmorPiercing() ? Bullet::ArmorPiercing : Bullet::Regular);
    b->setSpeed(_affinity == Alien && _variant == FastBulletTank ? 3 : 2);

    QRect fmr = QRect(0, 0, 2, 2);
    fmr.moveCenter(_geometry.center());
    int dx = 0, dy = 0;
    switch (_direction) {
    case North:
        dy = -1;
        break;
    case South:
        dy = 1;
        break;
    case West:
        dx = -1;
        break;
    case East:
        dx = 1;
        break;
    }
    fmr.translate(dx, dy);

    b->setInitialPosition(fmr.topLeft());
    b->setDirection(_direction);
    resetShootClock();

    _bullet = QSharedPointer<Bullet>(b);

    emit fired();
}

void Tank::resetShootClock()
{
    _shootTicks = 10; // as example
    if (_affinity == Friendly && _variant == BurstFireTank) {
        _shootTicks = 5; // that's a little bit wrong for burst. will be fixed later
    }
}

DynamicBlock::OutBoardAction Tank::outBoardAction() const { return DynamicBlock::StopMove; }

void Tank::clockTick()
{
    if (_shootTicks) {
        _shootTicks--;
    }
    DynamicBlock::clockTick();
}

void Tank::catchBullet()
{
    if( _shield != nullptr && _shield->isVisable() ) {
        qDebug("i have shield now");
        return;
    }
    
    if (!_armorLevel) {
        qDebug("Something went wrong");
        return;
    }
    _armorLevel--;
    if (_armorLevel) {
        emit armourChanged();
    } else {
        if( _bonusIndex > 0 ) {
            qDebug() << "bonus :" << _bonusIndex;
        }

        createBonus();
        emit tankDestroyed();
    }
}

void Tank::selfDestroy()
{
    _armorLevel = 1;
    catchBullet();
}

void Tank::createShield()
{
    if (_affinity == Friendly ) {
        if( _shield != nullptr && _shield->isVisable() ) {
            qDebug() << "already shielded";
            return;
        }

        auto s = new Shield();
        QRect fmr = QRect(0, 0, 4, 4);
        fmr.moveCenter(_geometry.center());
        s->setInitialPosition(fmr.topLeft());
        _shield = QSharedPointer<Shield>(s);

        qDebug() << "new shield";

        emit shielded();
    }
}

void Tank::createBonus()
{
    if (_affinity != Friendly && _bonusIndex > 0 && _bonusIndex <= BONUS_TIMER ) {
        auto b = new Bonus(_bonusIndex);

        QRect fmr = QRect(0, 0, 4, 4);
        fmr.moveCenter(_geometry.center());
        b->setInitialPosition(fmr.topLeft());
        _bonus = QSharedPointer<Bonus>(b);
        qDebug() << "new bonus, type:" << _bonusIndex;

        emit bonused(_bonusIndex);
    }
}


void Tank::catchBonus(int type)
{
    switch(type) {
    case BONUS_BASE:
        emit concreteBase();
        break;
    case BONUS_BUMP:
        emit destroyAll();
        break;
    case BONUS_DEFENSE:
        this->createShield();
        break;
    case BONUS_FORCE:
        this->_armorLevel++;
        emit levelUp();
        break;
    case BONUS_LIFE:
        emit lifeAdded();
        break;
    case BONUS_TIMER:
        emit freezed();
        break;
    }
}

} // namespace Tanks
