

#include "bonus.h"

namespace Tanks {

Bonus::Bonus(int type) :
    _type(type),
    _changed(false)
{
    _geometry.setWidth(4);
    _geometry.setHeight(4);
}

void Bonus::catched()
{
    if( !_changed ) {
        _changed = true;
        emit changed();
    }
}


} // namespace Tanks


