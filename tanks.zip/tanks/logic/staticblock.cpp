

#include "staticblock.h"

namespace Tanks {

StaticBlock::StaticBlock() { }

} // namespace Tanks
