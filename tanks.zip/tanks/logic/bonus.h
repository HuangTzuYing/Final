#ifndef TANKS_BONUS_H
#define TANKS_BONUS_H

#define BONUS_DURATION 10000
#define BONUS_BASE 1
#define BONUS_BUMP 2
#define BONUS_DEFENSE 3
#define BONUS_FORCE 4
#define BONUS_LIFE 5
#define BONUS_TIMER 6

#include <QtGlobal>
#include "staticblock.h"

namespace Tanks {

class Bonus : public StaticBlock {
    Q_OBJECT
public:
    Bonus(int type);

    int type() {return _type;}
    void catched();

signals:
    void changed();

private:
    int _type;
    bool _changed;

};

} // namespace Tanks

#endif // TANKS_BONUS_H
