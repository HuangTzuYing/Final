

#include "block.h"

namespace Tanks {

Block::Block() { }

} // namespace Tanks
