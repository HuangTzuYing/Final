

#include "humanplayer.h"
#include "board.h"
#include "game.h"

#include <QDebug>

namespace Tanks {

HumanPlayer::HumanPlayer(Game *game, int playerIndex) :
    _game(game), _playerIndex(playerIndex), _lifes(3), _shooting(false), _score(0)
{
}

int HumanPlayer::lifesCount() const { return _lifes; }
int HumanPlayer::score() const { return _score; }

void HumanPlayer::start()
{
    // _tank         = QSharedPointer<Tank>(new Tank(Friendly));
    _tank         = QSharedPointer<Tank>(new Tank(Friendly));
    _oldDirection = _tank->direction();
    moveToStart();
    emit newTankAvailable();
    _tank->createShield();

    // our handler is the last
    connect(_tank.data(), &Tank::tankDestroyed, this, &HumanPlayer::onTankDestroyed);
    connect(_tank.data(), &Tank::lifeAdded, this, &HumanPlayer::onLifeAdded);
}

void HumanPlayer::moveToStart()
{
    const auto &posList = _game->board()->friendlyStartPositions();
    _tank->setInitialPosition(posList[_playerIndex % posList.count()]);
}

void HumanPlayer::move(Direction dir)
{
    if (_tank) {
        Direction curDir = _tank->direction();
        _movingDir.erase(std::remove(_movingDir.begin(), _movingDir.end(), dir), _movingDir.end());
        _movingDir.push_front(dir);
        if (curDir != dir) {
            _oldDirection = curDir;
            _tank->setDirection(dir);
        }
    }
}

void HumanPlayer::fire() { _shooting = true; }

void HumanPlayer::stop(Direction dir)
{
    // we can stop pressing a key, but it does not mean other keys are not pressed
    // so we have to figure out what's left and continue moving
    _movingDir.erase(std::remove(_movingDir.begin(), _movingDir.end(), dir), _movingDir.end());
    if (!_movingDir.empty()) {
        auto dir = _movingDir.front();
        _movingDir.pop_front();
        move(dir);
    }
}

void HumanPlayer::stopFire() { _shooting = false; }

void HumanPlayer::clockTick()
{
    if (!_tank) {
        return; // nothing todo w/o tank
    }
    AbstractPlayer::clockTick();

    QRect             fmr;
    Board::BlockProps props;

    bool shouldMove  = !_movingDir.empty() && _tank->canMove();
    bool shouldShoot = (_shooting && _tank->canShoot());

    if (shouldMove || shouldShoot) {
        fmr   = _tank->forwardMoveRect(); // space before tank it's going to occupy
        props = _game->board()->rectProps(fmr);
    }

    if (shouldMove && !(props & Board::TankObstackle)) {
        _tank->move();
        _oldDirection = _tank->direction();
    }
    //    else if (_oldDirection != _tank->direction() && _tank->canMove()) {
    //        emit moved();
    //        _oldDirection = _tank->direction();
    //    }

    if (shouldShoot) {
        _tank->fire();
    }
}

void HumanPlayer::onTankDestroyed()
{
    if (!_lifes) {
        qDebug("Something went wrong");
        return;
    }
    _lifes--;
    if (_lifes) {
        start();
    } else {
        _tank.clear();
    }
    emit lifeLost();
}

void HumanPlayer::onLifeAdded() 
{
    if (!_lifes) {
        qDebug("Something went wrong");
        return;
    }
    _lifes++;
    emit lifeAdd();
}

void HumanPlayer::killAll()
{
    if (_tank) {
        _lifes = 1;
        _tank->selfDestroy();
    }
}

void HumanPlayer::addScore(int score)
{
    _score += score;
}


} // namespace Tanks
